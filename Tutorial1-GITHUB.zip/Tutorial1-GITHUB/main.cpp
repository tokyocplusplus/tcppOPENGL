#include<iostream>
#include<glad/glad.h>
#include<GLFW/glfw3.h>

int main() {
	//initialzing glfw
	glfwInit();
	//changing opengl version
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	//choosing opengl profile
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	//creating window object
	GLFWwindow* window = glfwCreateWindow(1280, 720, "tcpp", NULL, NULL);
	if (!window) {
		std::cerr << "FAILED TO INIT GLFW";
		glfwTerminate();
		return -1;
	}
	//TELL IT THAT WE WANT TO USE THE WINDOW
	glfwMakeContextCurrent(window);
	//TELL IT THAT WE WANT TO USE GLAD
	gladLoadGL();
	//TELL IT WHERE TO START DRAWING
	glViewport(0, 0, 1280, 720);
	//color for the front color
	glClearColor(2.0f, 0.0f, 2.0f, 1.0f);
	//Seperating the back buffer from the front
	glClear(GL_COLOR_BUFFER_BIT);
	//SWAPPING THE BACK AND FRONT BUFFER
	glfwSwapBuffers(window);
	//MAIN LOOP
	while (!glfwWindowShouldClose(window)) {
		//poll events
		glfwPollEvents();
	}
	//DE-INIT
	glfwDestroyWindow(window);
	glfwTerminate();
}