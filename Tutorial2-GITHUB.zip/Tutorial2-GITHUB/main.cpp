#include<iostream>
#include<glad/glad.h>
#include<GLFW/glfw3.h>
//https://www.youtube.com/watch?v=KG9ZXKaJWwY&list=PLPaoO-vpZnumdcb4tZc4x5Q-v7CkrQ6M-&index=4
//0:22

/*SHADER CODE*/
const char* vertexShaderSource = R"(
#version 330 core
layout (location = 0) in vec3 aPos;

void main() {
	gl_Position = vec4(aPos.xyz, 1.0);
}
)";
const char* fragmentShaderSource = R"(
#version 330 core

void main() {
	gl_FragColor = vec4(2.0f,0.0f,2.0f, 1.0f);
}
)";
/*!SHADER CODE*/

void processInput(GLFWwindow* window) {
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
		glfwSetWindowShouldClose(window, 1);
	}
}

int main() {
	/*INITIALIZING GLFW*/
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	/*!INITIALIZING GLFW*/

	/*VERTICES AND INDICES*/
	/*----------------------------------------*/
	GLfloat vertices[] = {
		 0.0f, 0.5f,0.0f, // top   vertex
		-0.5f,-0.5f,0.0f, // left  vertex
		 0.5f,-0.5f,0.0f  // right vertex
	};
	/*----------------------------------------*/
	/*!VERTICES AND INDICES*/

	/*WINDOW INITIALIZATION*/
	GLFWwindow* window = glfwCreateWindow(1280, 720, "tcpp", NULL, NULL);
	if (!window) {
		std::cerr << "FAILED TO INIT GLFW";
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	gladLoadGL();
	glViewport(0, 0, 1280, 720);
	/*!WINDOW INITIALIZATION*/

	/*SHADERS*/
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);

	GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);

	GLuint shader = glCreateProgram();
	glAttachShader(shader, vertexShader);
	glAttachShader(shader, fragmentShader);
	glLinkProgram(shader);

	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);
	/*!SHADERS*/
	
	/*BUFFERS*/
	GLuint VAO;
	glGenVertexArrays(1, &VAO);

	GLuint VBO;
	glGenBuffers(1, &VBO);

	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);

	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (void*)0);
	glEnableVertexAttribArray(0);

	//UNBIND EVERYTHING
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
	/*!BUFFERS*/

	/*MAIN LOOP*/
	while (!glfwWindowShouldClose(window)) {
		
		glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);
		glUseProgram(shader);
		glBindVertexArray(VAO);
		glDrawArrays(GL_TRIANGLES, 0, 3);
		//HANDLE GLFW EVENTS
		processInput(window);
		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	/*!MAIN LOOP*/

	/*DE-INITIALIZE EVERYTHING*/
	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &VBO);
	glDeleteProgram(shader);
	glfwDestroyWindow(window);
	glfwTerminate();
	return 0;
	/*!DE-INITIALIZE EVERYTHING*/
}

/*
NOTES

GRAPHICS PIPELINE WORKS LIKE THIS

VERTEX DATA --> Vertex Shader
Vertex Shader --> Shape Assembly
Shape Assembly --> Geometry Shader
Geometry Shader --> Tests and Blending
Tests and Bleding --> Fragment Shader
Fragment Shader --> Rasterization
*/